create database db_librarysite

use db_librarysite

create table tbl_Books
(
BookID int identity(1001,1) primary key,
BookName varchar(100) not null,
AuthorName varchar(100) not null,
BookImage varchar(100) not null,
BookAddedDate DateTime not null
 )

 

 select * from  tbl_Students

 create table tbl_Students
 (
 StudentID int Identity(1,1) primary key,
 StudentName varchar(100) not null,
 StudentEmailId varchar(100) not null,
 StudentDOB Datetime not null,
 StudentPassword varchar(100) not null,
 StudentGender varchar(100) not null check(StudentGender in('male','female')),
 StudentImageAddr varchar(100) not null
 )

 select * from tbl_students





 alter proc proc_addStudent(@name varchar(100),@email varchar(100),@dob datetime,@pwd varchar(100),@gender varchar(100),@imageaddr varchar(100))
 as
 begin
 insert into tbl_students values(@name,@email,@dob,@pwd,@gender,@imageaddr)
 return @@identity
 end

 create proc proc_login(@id int,@pwd varchar(100))
 as
 begin
 declare @count int=0
 Select @count=count(*) from tbl_Students 
 where StudentID=@id and StudentPassword=@pwd
 return @count
 end

 create proc proc_findStudent(@id int)
 as
 begin
 select * from tbl_students where StudentID=@id
 end

alter proc proc_addBook(@name varchar(100),@Authname varchar(100),@image varchar(100))
as
begin
insert into tbl_Books values(@name,@Authname,@image,getdate())
return @@identity
end 

alter proc proc_searchBook(@key varchar(100))
as 
begin
Select * from tbl_Books where BookID like'%' +@key+ '%'
                        or BookName like '%' +@key+ '%'
end



